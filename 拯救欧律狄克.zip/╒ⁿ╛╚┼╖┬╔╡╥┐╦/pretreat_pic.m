function result = pretreat_pic (pic)
bw = ~imbinarize(rgb2gray(pic),0.5);    %matlab2020a版本用这两个函数代替im2bw
se=strel('line',400,0);                 %strel结构化，以便后期进行图像处理
bw_dilate=imdilate(bw,se);              %imdilate膨胀图像
bw_dilate_erode=imerode(bw_dilate,strel('line',1000,0)); %imerode腐蚀图像
bw_re=imreconstruct(bw_dilate_erode,bw_dilate);
result=imreconstruct(bw_re,bw);
end