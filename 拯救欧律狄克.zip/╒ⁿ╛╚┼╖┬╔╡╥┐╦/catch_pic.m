function x= catch_pic(im)
%精确切割手写数字图片
[r,c]=find(im);
x=im(min(r):max(r),min(c):max(c));
end
