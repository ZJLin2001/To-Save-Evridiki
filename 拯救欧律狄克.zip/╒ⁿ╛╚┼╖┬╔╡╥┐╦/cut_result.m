function q1 = cut_result(q) 
   [heng,zong]=size(q);
   hs=sum(q);
   hs0=sum(q,2);  %这里表示行之和
   hs1=hs0';       %将行之和转置
   
   %初始化裁剪信息
   y = 5; %行

   up = zeros(y);
   down = zeros(y);
   left = zeros(y,x);
   right = zeros(y,x);
   
   for i=1:y
        while(hs1(shang)==0&&shang<heng)   %找到图中白像素点，即有数字的部分，按行之和找
            shang=shang+1;
        end
            xia=shang;
        while(hs1(xia)>0&&xia<heng)  %按列找找到不存在白像素的列，由于找到上边最先出现白像素的列直到找到最下边没有白像素的行，之间的就是整个数字
            xia=xia+1;
        end
        up(i) = shang;
        down(i) = xia;
        shang = xia+2;
        for j=1:x
             while(hs(zuo)==0&&zuo<zong)   %找到图中白像素点，即有数字的部分，按列之和找
             zuo=zuo+1;
             end
             you=zuo;
             while(hs(you)>0&&you<zong)  %按列找找到不存在白像素的列，由于找到左边最先出现白像素的列直到找到最右边没有白像素的列，之间的就是整个数字
             you=you+1;
             end
             left(i,j)=zuo;
             right(i,j)=you;
             zuo = you + 2;
        end
        zuo = 1;
        you = 1;
   end

   
   for i=1:y
        q1 = q(up(i):down(i),:);
   end
end