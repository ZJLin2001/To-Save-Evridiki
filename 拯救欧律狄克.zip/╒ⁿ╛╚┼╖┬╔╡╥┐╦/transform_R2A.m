function [i1,j1] = transform_R2A (i,r,v)
     i1 = ceil(i/v);
     j1 = mod(i,v);
     if j1 == 0
        j1 = v;
     end
end