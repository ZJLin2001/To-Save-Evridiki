%此脚本用于调试手写数字识别的结果。相当于未封装的APP
clc,clear,close all;
picture_0 = imread('num2.jpg');
f = 'mynet_handwriting.mat';      %此处可更改载入的训练网络
result = pretreat_pic(picture_0);
figure,imshow(result);
imwrite(result,'picture_0.jpg','jpg'); 
lastresult = numPredict(picture_0,f);
D = transform_A2R(lastresult,inf,0,inf,0);
[R,index] = floyd(D);   
%由状态矩阵D得到路由矩阵R
%输出

i=1;
[r,v]=size(lastresult);
j = r*v;
DisplayPath(index, i, j);
[i1,j1]=transform_R2A(i,r,v);
R(i,j)+lastresult(i1,j1)