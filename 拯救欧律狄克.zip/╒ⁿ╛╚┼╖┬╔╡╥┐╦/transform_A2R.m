function R = transform_A2R (A,shang,xia,zuo,you)
    [r,v]=size(A);
    l = r*v;
    R = zeros(l);
    %以下是由A推导R，但遍历是由R->A,故会使用一次transform_R2A
    for i = 1:l
        for j = 1:l
            if i~=j
                [i1,j1] = transform_R2A(i,r,v);
                [i2,j2] = transform_R2A(j,r,v);
                i_d = i2 - i1;
                j_d = j2 - j1;
                
                if abs(i_d)+abs(j_d)>1
                    R(i,j) = inf;
                    
                elseif i_d == 1        
                    R(i,j) = A(i2,j2)+you;

                elseif i_d == -1
                    R(i,j) = A(i2,j2)+zuo;

                elseif j_d == 1
                    R(i,j) = A(i2,j2)+xia;

                elseif j_d == -1
                    R(i,j) = A(i2,j2)+shang;
                
                end
            end
        end
    end
end