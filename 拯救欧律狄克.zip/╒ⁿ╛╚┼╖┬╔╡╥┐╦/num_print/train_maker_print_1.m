picture_0 = imread('train_num_print.jpg');
bw = ~imbinarize(rgb2gray(picture_0),0.5); %matlab2020a版本用这两个函数代替im2bw
se=strel('line',400,0);            %strel结构化，以便后期进行图像处理
bw_dilate=imdilate(bw,se);         %imdilate膨胀图像
bw_dilate_erode=imerode(bw_dilate,strel('line',1000,0)); %imerode腐蚀图像
bw_re=imreconstruct(bw_dilate_erode,bw_dilate);
result=imreconstruct(bw_re,bw);
picture_pre = result; 
[r,c]=find(picture_pre);
picture_pre = picture_pre(min(r):max(r),min(c):max(c));
[h,w]=size(picture_pre);
[r,c]=find(picture_pre);

hs=sum(picture_pre);
hs0=sum(picture_pre,2);  %这里表示行之和，这时应该是竖着写了两个数字及其以上，除了那种奇葩写得贼长那种
hs1=hs0';                %将行之和转置
a=1;b=1;c=1;d=1;i=1;j=0;
x=1;
while(c<h)
    while(hs1(c)==0&&c<h)
        c=c+1;
    end
    d=c;
    while(hs1(d)>0&&d<h)
        d=d+1;
    end
    if (d-c>2)
        hresult=picture_pre(c:d,:);
        [r,z]=find(hresult);
        m=min(r);n=max(r);
        figure,imshow(hresult);
        filename=[num2str(j),'.jpg'];
        imwrite(hresult,filename,'jpg');
    end
    a=1;
    b=1;
    c=d;
    x=i-1;
    i=1;
    j=j+1;
end
y=j-1;