for t = 0:9
filename = [num2str(t),'.jpg'];
picture_pre = imread(filename);
[h,w]=size(picture_pre);
[r,v]=find(picture_pre);
folderName = num2str(t);
mkdir(folderName);  % 新建一个文件夹 

hs=sum(picture_pre);
hs0=sum(picture_pre,2);  %这里表示行之和，这时应该是竖着写了两个数字及其以上，除了那种奇葩写得贼长那种
hs1=hs0';                %将行之和转置
a=1;b=1;c=1;d=1;i=1;j=1;
x=1;
figure
while(a<w)
   while(hs(a)==0&&a<w)
       a=a+1;
       end
       b=a;
        while(hs(b)>0&&b<w)
            b=b+1;
        end
            if(b-a>1)
                hresult=picture_pre(:,a:b);
                [x1,x2] = find(hresult);
                hresult=hresult(min(x1):max(x1),min(x2):max(x2));
                imshow(hresult);
                filename=['D:\俄尔普斯\num_print\',folderName,'\',num2str(i),'.bmp'];
                imwrite(hresult,filename,'bmp');
                i=i+1;
             end
             a=b;
        end
end