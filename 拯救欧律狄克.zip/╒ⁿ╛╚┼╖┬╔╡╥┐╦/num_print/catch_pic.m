function x= catch_pic(im)
[r,c]=find(im);
x=im(min(r):max(r),min(c):max(c));
end
