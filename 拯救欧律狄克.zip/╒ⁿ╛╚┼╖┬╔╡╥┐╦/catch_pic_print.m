function x= catch_pic_print(im)
%精确切割印刷体数字图片
[r,c]=find(im);
x=im(min(r+2):max(r-2),min(c+2):max(c-2));
end
