%此脚本用于声明值不能降为0规则的情况下使用BFS进行动态规划判断。
clc,clear,close all;
picture_0 = imread('num5.jpg');  %此处手动选择载入图片
picture_1 = ~im2bw(picture_0);
picture_2 = catch_pic_print(picture_1);
picture_3 = ~im2bw(picture_2);
picture_4 = catch_pic_print(picture_3);
figure,imshow(picture_4);
picture_pre = picture_4;
%哦，瞧一瞧，我亲爱的老伙计，那么多格子，让图像处理难度上了个档次哟
%下部分和手写数字没有什么区别
[h,w]=size(picture_pre);
hs=sum(picture_pre);
hs0=sum(picture_pre,2);  
hs1=hs0';                
a=1;b=1;c=1;d=1;i=1;j=1;
splitfs={};points=[];
lastresult = [];
x=1;

while(c<h)
    while(hs1(c)==0&&c<h)
        c=c+1;
    end
    d=c;
    while(hs1(d)>0&&d<h)
        d=d+1;
    end
    if (d-c>2)
        while(a<w)
            while(hs(a)==0&&a<w)
                a=a+1;
            end
            b=a;
            while(hs(b)>0&&b<w)
                b=b+1;
            end
            
            if(b-a>2)
                hresult=picture_pre(c+4:d-4,a+4:b-4);
                [r,z]=find(hresult);
                lastresult(j,i)= numPredict_print_single(hresult);
                m=min(r);n=max(r);
                i=i+1;
             end
             a=b;
        end
    end
    a=1;
    b=1;
    c=d;
    x=i-1;
    i=1;
    j=j+1;
end
clc 
lastresult
[Life,index] = BFS_find_max(lastresult);
disp(['------------以下为路径输出---------------',newline]);
index
Life

