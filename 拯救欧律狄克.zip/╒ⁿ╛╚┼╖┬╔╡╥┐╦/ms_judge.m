function a = ms_judge (pic)
    [r,v] = size(pic);
    if v> r*(1.5)
        a = 1;
    else
        a = 0
    end
end