function result = pretreat_pic_train (pic)
bw = im2bw(pic);                   %im2bw老是警告图片已经二值化，但是用imbinaries会出现非rgb图片无法转换的情况
se=strel('line',400,0);            %strel结构化，以便后期进行图像处理
bw_dilate=imdilate(bw,se);         %imdilate膨胀图像
bw_dilate_erode=imerode(bw_dilate,strel('line',1000,0)); %imerode腐蚀图像，老三样结束
bw_re=imreconstruct(bw_dilate_erode,bw_dilate);
result=imreconstruct(bw_re,bw);
end