picture_0 = imread('num_train_pre.jpg');

[h,w]=size(picture_pre);
[r,c]=find(picture_pre);
hs=sum(picture_pre);
hs0=sum(picture_pre,2);  %这里表示行之和，这时应该是竖着写了两个数字及其以上，除了那种奇葩写得贼长那种
hs1=hs0';                %将行之和转置
a=1;b=1;c=1;d=1;i=1;j=1;
x=1;
figure
while(c<h)
    while(hs1(c)==0&&c<h)
        c=c+1;
    end
    d=c;
    while(hs1(d)>0&&d<h)
        d=d+1;
    end
    if (d-c>2)
        hresult=picture_pre(c:d,:);
        [r,z]=find(hresult);
        m=min(r);n=max(r);
        imshow(hresult);
        
            
        filename=['D:\Matlab\img_ORPS\picture',num2str(j),'.jpg']; %该路径可能有变。此处只是做一次训练集制作。
        imwrite(hresult,filename,'jpg');
    end
    a=1;
    b=1;
    c=d;
    x=i-1;
    i=1;
    j=j+1;
end
y=j-1;

