function number = numPredict_print_single(pic)
    pic = ~im2bw(pic);
    picture_pre = catch_pic(pic);
    [h,w]=size(picture_pre);
    hs=sum(picture_pre);
    a=1;b=1;i=0; numlist = [];
    size_pic = 16;
    while(a<w)
        while(hs(a)==0&&a<w)
            a=a+1;
        end
            b=a;
        while(hs(b)>0&&b<w)
                b=b+1;
        end
            
            if(b-a>1)
                i=i+1;
                hresult=picture_pre(:,a+1:b-1);
                hresult=double(catch_pic(hresult));
                %简易去噪点操作
                se = strel('line',100,0);            %strel结构化，以便后期进行图像处理
                bw_dilate=imdilate(hresult,se);         %imdilate膨胀图像
                bw_dilate_erode=imerode(bw_dilate,strel('line',800,0)); %imerode腐蚀图像
                bw_re=imreconstruct(bw_dilate_erode,bw_dilate);
                result=imreconstruct(bw_re,hresult);
                [r,v]= size(result);
                if  v > r*(1.5)
                    numlist(i) = -1;
                else
                    numlist(i) = number_single(result);
                end
            end
        a=b;
    end
    if i==1
        number = numlist(1);
    elseif i == 2
        if numlist(1) == -1;
            number = numlist(2)*(-1);
        else 
            number = 10*numlist(1)+numlist(2);
        end
    elseif i == 3
            number = (-10)*numlist(2)-numlist(3);
    end
end