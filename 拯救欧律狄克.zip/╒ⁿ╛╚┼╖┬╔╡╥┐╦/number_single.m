function number = number_single(pic)
    load mynet_print.mat;
    pic = imresize(pic,[40,40]);
    number = predict(net,pic(:)');
end