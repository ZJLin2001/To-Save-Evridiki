clear,clc,close all;
k=1;
for m=0:9
    for n=1:20
        f=imread(strcat('num_print\',int2str(m),'\',int2str(n),'.bmp'));
        f=pretreat_pic_train(f);    
        f=catch_pic(f);
        f=imresize(f,[40,40]);
        xx=double(f(:));
        P(k,:)=xx';
        T(k,1)=m;
        k=k+1;
%         if m == 1
%             figure,imshow(f);
%         end
    end
end
net=fitcecoc(P,T);
save mynet_print net;





