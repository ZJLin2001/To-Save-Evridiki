function lastresult = numPredict_print(picture_0)
%印刷体数字识别脚本
picture_1 = ~im2bw(picture_0);
picture_2 = catch_pic_print(picture_1);
picture_3 = ~im2bw(picture_2);
picture_pre = catch_pic_print(picture_3);

[h,w]=size(picture_pre);
hs=sum(picture_pre);
hs0=sum(picture_pre,2);  
hs1=hs0';                
a=1;b=1;c=1;d=1;i=1;j=1;
lastresult = [];
while(c<h)
    while(hs1(c)==0&&c<h)
        c=c+1;
    end
    d=c;
    while(hs1(d)>0&&d<h)
        d=d+1;
    end
    if (d-c>2)
        while(a<w)
            while(hs(a)==0&&a<w)
                a=a+1;
            end
            b=a;
            while(hs(b)>0&&b<w)
                b=b+1;
            end
            
            if(b-a>2)
                hresult=picture_pre(c+4:d-4,a+4:b-4);
                lastresult(j,i)= numPredict_print_single(hresult);
                i=i+1;
             end
             a=b;
        end
    end
    a=1;
    b=1;
    c=d;
    i=1;
    j=j+1;
end
end
