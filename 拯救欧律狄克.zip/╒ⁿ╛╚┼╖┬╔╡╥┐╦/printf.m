function y = printf(k)
    k1 = takefeatures1(k);
    load('w1');
    load('w2');
    load('w3');
    %隐含层1各个节点的输入
         in_incell=k1(:,1)'*w1;
    %隐含层1各个节点的输出
        in_outcell=1./(1+exp(-in_incell));
    %隐含层2各个节点的输入
         hd_incell=in_outcell*w2;
    %隐含层2各个节点的输出
        hd_outcell=1./(1+exp(-hd_incell));
    %输出层各个节点的输入
        ot_incell=hd_outcell*w3;
    %输出层的输出
        ot_outcell=1./(1+exp(-ot_incell));
        y = find(ot_outcell==max(ot_outcell))
end
        