function varargout = GUI(varargin)
% MATLAB演示APP脚本，
% DAUNXUJIAN1 MATLAB code for daunxujian1.fig
%      DAUNXUJIAN1, by itself, creates a new DAUNXUJIAN1 or raises the existing
%      singleton*.
%
%      H = DAUNXUJIAN1 returns the handle to a new DAUNXUJIAN1 or the handle to
%      the existing singleton*.
%
%      DAUNXUJIAN1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DAUNXUJIAN1.M with the given input arguments.
%
%      DAUNXUJIAN1('Property','Value',...) creates a new DAUNXUJIAN1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before daunxujian1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to daunxujian1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
 
% Edit the above text to modify the response to help daunxujian1
 
% Last Modified by GUIDE v2.5 23-Oct-2020 21:52:34
 
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @daunxujian1_OpeningFcn, ...
                   'gui_OutputFcn',  @daunxujian1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
 
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
 
 
% --- Executes just before daunxujian1 is made visible.
function daunxujian1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to daunxujian1 (see VARARGIN)
% Choose default command line output for daunxujian1
handles.output = hObject;
handles.Result = [];
handles.File = [];
% Update handles structure
guidata(hObject, handles);
clc; warning off all;
InitAxes(handles);
% UIWAIT makes daunxujian1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
 
 
% --- Outputs from this function are returned to the command line.
function varargout = daunxujian1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
% Get default command line output from handles structure
varargout{1} = handles.output;
 
 
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
    '*.*','All Files' },'载入图像',...
    fullfile(pwd, 'images'));
I = imread(fullfile(pathname, filename));
Result = Process_Main(I);
handles.File = fullfile(pathname, filename);
handles.Result = Result;
guidata(hObject, handles);
InitAxes(handles)
axes(handles.axes1); imshow(handles.Result.Image); title('原图像');
 
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(handles.Result)
    axes(handles.axes1); imshow(handles.Result.Image); title('原图像');
    axes(handles.axes2); imshow(handles.Result.Medfilt); title('中值滤波图像');
end
 
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(handles.Result)
    axes(handles.axes1); imshow(handles.Result.Image); title('原图像');
    axes(handles.axes2); imshow(handles.Result.Medfilt); title('中值滤波图像');
    axes(handles.axes3); imshow(handles.Result.Normalize); title('归一化图像');
end
 
% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(handles.Result)
    axes(handles.axes1); imshow(handles.Result.Image); title('原图像');
    axes(handles.axes2); imshow(handles.Result.Medfilt); title('中值滤波图像');
    axes(handles.axes3); imshow(handles.Result.Normalize); title('归一化图像');
    axes(handles.axes4); imshow(handles.Result.Bww); title('二值化图像');
end
 
% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(handles.Result)
    axes(handles.axes1); imshow(handles.Result.Image); title('原图像');
    axes(handles.axes2); imshow(handles.Result.Medfilt); title('中值滤波图像');
    axes(handles.axes3); imshow(handles.Result.Normalize); title('归一化图像');
    axes(handles.axes4); imshow(handles.Result.Bww); title('二值化图像');
    axes(handles.axes6); imshow(handles.Result.Thin); title('细化处理');
    axes(handles.axes5); imshow(handles.Result.Bw); title('特征提取');
    hold on;
    h = [];
    for i = 1 : length(handles.Result.hs) %绘制水平线
        h = [h plot([1 handles.Result.sz(2)], [handles.Result.hs(i) handles.Result.hs(i)], 'r-')];
    end
    for i = 1 : length(handles.Result.vs)%绘制竖直线
        h = [h plot([handles.Result.vs(i) handles.Result.vs(i)], [1 handles.Result.sz(1)], 'g-')];
    end
    h = [h plot(handles.Result.x1, handles.Result.y1, 'y-')];%绘制左对角线
    h = [h plot(handles.Result.x2, handles.Result.y2, 'm-')];%绘制右对角线
end
 
% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uiputfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
    '*.*','All Files' },'Save Image',...
    fullfile(pwd, 'Result/result.png'));
if ~isequal(filename, 0)
    imwrite(handles.Result.label, fullfile(pathname, filename));
    msgbox('保存图像成功！', '信息提示框');
end
 
 
% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
choice = questdlg('确定退出?', ...
    '退出', ...
    '是','否','否');
switch choice
    case '是'
        close;
    otherwise
        return;
end
 
 
function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 
% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
 
 
% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
 
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
 
 
% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit1,'string',handles.Result.label);
 
 
% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(handles.Result)
    axes(handles.axes1); imshow(handles.Result.Image); title('原图像');
    axes(handles.axes2); imshow(handles.Result.Medfilt); title('中值滤波图像');
    axes(handles.axes3); imshow(handles.Result.Normalize); title('归一化图像');
    axes(handles.axes4); imshow(handles.Result.Bww); title('二值化图像');
    axes(handles.axes6); imshow(handles.Result.Thin); title('细化处理');
end
