function [LargestPathValue,index] = BFS_find_max(lastresult)
% 函数功能：输入矩阵，输出最短路径值以及路线（方向从左上到右下）
[r,v] = size(lastresult);
d = zeros(r,v);
index = zeros(r,v);	%路由输出矩阵
d(1,1) = lastresult(1,1);
% 计算第一行和第一列的最大路径值
for i = 2:v
    if d(1,i-1) ~= -inf
        d(1,i) = d(1,i-1)+(lastresult(1,i));
    else
        d(1,i) = -inf;  %以-150代表走不动了
    end
end
for i = 2:r
    if d(i-1,1) ~= -inf
        d(i,1) = d(i-1,1)+(lastresult(i,1));
    else
        d(i,1) = -inf;
    end
end
% 计算各个子路径终点的最大路径值
for i = 2:r
	for j = 2:v
		d(i,j) = lastresult(i,j) + max(d(i-1,j),d(i,j-1));
        if d(i,j) <= 0 
            d (i,j) = -inf;
        end
	end
end
LargestPathValue = d(r,v);
% 将起点和终点标记为1
index(1,1) = 1;
index(r,v) = 1;
 
i = r;j = v;  %从终点处反向向起点处遍历
while 1
	if i == 1 & j == 1  %判定是否到达终点
		break;
	elseif i == 1 		%判定是否到达边界
		index(1,1:j) = 1;
		break;
	elseif j == 1 		%判定是否到达边界
		index(1:i,j) = 1;
		break;
	end
 
	left = d(i-1,j);	%向左
	upon = d(i,j-1);	%向上
	%根据左边和上边的值来判定行进方向，相等则默认向左
	if left >= upon		
		index(i-1,j) = 1;
		i = i - 1;
    else
		index(i,j-1) = 1;
		j = j - 1;
	end
end